import com.sap.conn.jco.JCoDestination;
import com.sap.conn.jco.JCoDestinationManager;
import com.sap.conn.jco.JCoField;
import com.sap.conn.jco.JCoFunction;
import com.sap.conn.jco.JCoParameterList;
import com.sap.conn.jco.JCoTable;
import com.sap.conn.jco.ext.DestinationDataEventListener;
import com.sap.conn.jco.ext.DestinationDataProvider;
import com.sap.conn.jco.ext.Environment;

import java.io.FileInputStream;
import java.util.Properties;

public class SapBomExtractor {

    private static final String DESTINATION_NAME = "S4H_DESTINATION";
    private static final String CONFIG_FILE = "config/sap.properties";
    private static final String FUNCTION_NAME = "CSAP_MAT_BOM_READ";

    private static final String MATERIAL = "PLM001007";
    private static final String PLANT = "1001";
    private static final String BOM_USAGE = "3";
    private static final String ALTERNATIVE = "1";

    public static void main(String[] args) {

        System.out.println("========================================");
        System.out.println("SAP BOM EXTRACTION");
        System.out.println("========================================");

        try {
            Properties properties = loadProperties();

            registerDestinationProvider(properties);

            JCoDestination destination =
                JCoDestinationManager.getDestination(
                    DESTINATION_NAME
                );

            System.out.println();
            System.out.println("Testing SAP connection...");

            destination.ping();

            System.out.println("SAP connection successful.");
            System.out.println(
                "System ID : "
                + destination.getAttributes().getSystemID()
            );
            System.out.println(
                "Client    : "
                + destination.getAttributes().getClient()
            );
            System.out.println(
                "Host      : "
                + destination.getAttributes().getPartnerHost()
            );

            System.out.println();
            System.out.println(
                "Searching for SAP function: "
                + FUNCTION_NAME
            );

            JCoFunction function =
                destination
                    .getRepository()
                    .getFunction(FUNCTION_NAME);

            if (function == null) {
                throw new RuntimeException(
                    "SAP function was not found: "
                    + FUNCTION_NAME
                );
            }

            System.out.println(
                "Function found: " + FUNCTION_NAME
            );

            JCoParameterList importParameters =
                function.getImportParameterList();

            System.out.println();
            System.out.println(
                "========================================"
            );
            System.out.println("AVAILABLE IMPORT PARAMETERS");
            System.out.println(
                "========================================"
            );

            printParameterMetadata(importParameters);

            System.out.println();
            System.out.println(
                "========================================"
            );
            System.out.println("SETTING INPUT PARAMETERS");
            System.out.println(
                "========================================"
            );

            setRequiredParameter(
                importParameters,
                "MATERIAL",
                MATERIAL
            );

            setRequiredParameter(
                importParameters,
                "PLANT",
                PLANT
            );

            setRequiredParameter(
                importParameters,
                "BOM_USAGE",
                BOM_USAGE
            );

            setOptionalParameter(
                importParameters,
                "ALTERNATIVE",
                ALTERNATIVE
            );

            setOptionalParameter(
                importParameters,
                "VALID_FROM",
                ""
            );

            setOptionalParameter(
                importParameters,
                "VALID_TO",
                ""
            );

            setOptionalParameter(
                importParameters,
                "CHANGE_NO",
                ""
            );

            System.out.println();
            System.out.println(
                "Executing " + FUNCTION_NAME + "..."
            );

            function.execute(destination);

            System.out.println(
                FUNCTION_NAME + " executed successfully."
            );

            System.out.println();
            System.out.println(
                "========================================"
            );
            System.out.println("EXPORT PARAMETERS");
            System.out.println(
                "========================================"
            );

            printParameterValues(
                function.getExportParameterList()
            );

            System.out.println();
            System.out.println(
                "========================================"
            );
            System.out.println("CHANGING PARAMETERS");
            System.out.println(
                "========================================"
            );

            printParameterValues(
                function.getChangingParameterList()
            );

            JCoParameterList tableParameters =
                function.getTableParameterList();

            System.out.println();
            System.out.println(
                "========================================"
            );
            System.out.println("AVAILABLE TABLE PARAMETERS");
            System.out.println(
                "========================================"
            );

            printParameterMetadata(tableParameters);

            printTable(
                tableParameters,
                "T_STKO",
                "BOM HEADER"
            );

            printTable(
                tableParameters,
                "T_STPO",
                "BOM COMPONENTS"
            );

            System.out.println();
            System.out.println(
                "========================================"
            );
            System.out.println("BOM EXTRACTION COMPLETED");
            System.out.println(
                "========================================"
            );

        } catch (Exception e) {
            System.err.println();
            System.err.println(
                "========================================"
            );
            System.err.println("BOM EXTRACTION FAILED");
            System.err.println(
                "========================================"
            );
            System.err.println(
                "Error type : "
                + e.getClass().getName()
            );
            System.err.println(
                "Message    : "
                + e.getMessage()
            );

            e.printStackTrace();
        }
    }

    private static void setRequiredParameter(
        JCoParameterList parameters,
        String parameterName,
        String value
    ) {
        if (parameters == null) {
            throw new RuntimeException(
                "SAP import parameter list is unavailable."
            );
        }

        try {
            parameters.setValue(parameterName, value);

            System.out.println(
                "Set "
                + parameterName
                + " = "
                + value
            );

        } catch (Exception e) {
            throw new RuntimeException(
                "Required SAP import parameter is unavailable: "
                + parameterName,
                e
            );
        }
    }

    private static void setOptionalParameter(
        JCoParameterList parameters,
        String parameterName,
        String value
    ) {
        if (parameters == null) {
            return;
        }

        try {
            parameters.setValue(parameterName, value);

            String displayValue =
                value == null || value.length() == 0
                    ? "<blank>"
                    : value;

            System.out.println(
                "Set "
                + parameterName
                + " = "
                + displayValue
            );

        } catch (Exception e) {
            System.out.println(
                "Optional parameter not available: "
                + parameterName
            );
        }
    }

    private static void printParameterMetadata(
        JCoParameterList parameters
    ) {
        if (parameters == null) {
            System.out.println(
                "No parameters are available."
            );
            return;
        }

        int parameterCount = 0;

        for (JCoField field : parameters) {
            parameterCount++;

            System.out.println(
                parameterCount
                + ". "
                + field.getName()
                + " | Type: "
                + field.getTypeAsString()
            );
        }

        if (parameterCount == 0) {
            System.out.println(
                "No parameters are available."
            );
        }
    }

    private static void printParameterValues(
        JCoParameterList parameters
    ) {
        if (parameters == null) {
            System.out.println(
                "No parameters were returned."
            );
            return;
        }

        int parameterCount = 0;

        for (JCoField field : parameters) {
            parameterCount++;

            try {
                System.out.println(
                    field.getName()
                    + " = "
                    + field.getString()
                );

            } catch (Exception e) {
                System.out.println(
                    field.getName()
                    + " = <complex structure>"
                );
            }
        }

        if (parameterCount == 0) {
            System.out.println(
                "No parameters were returned."
            );
        }
    }

    private static void printTable(
        JCoParameterList tableParameters,
        String tableName,
        String displayName
    ) {
        System.out.println();
        System.out.println(
            "========================================"
        );
        System.out.println(
            displayName + ": " + tableName
        );
        System.out.println(
            "========================================"
        );

        if (tableParameters == null) {
            System.out.println(
                "No SAP table parameters were returned."
            );
            return;
        }

        try {
            JCoTable table =
                tableParameters.getTable(tableName);

            if (table == null) {
                System.out.println(
                    "Table is unavailable: " + tableName
                );
                return;
            }

            int rowCount = table.getNumRows();

            System.out.println(
                "Table name : " + tableName
            );
            System.out.println(
                "Row count  : " + rowCount
            );

            if (rowCount == 0) {
                System.out.println(
                    "No records were returned."
                );
                return;
            }

            for (
                int rowIndex = 0;
                rowIndex < rowCount;
                rowIndex++
            ) {
                table.setRow(rowIndex);

                System.out.println();
                System.out.println(
                    "----------------------------------------"
                );
                System.out.println(
                    "ROW " + (rowIndex + 1)
                );
                System.out.println(
                    "----------------------------------------"
                );

                for (JCoField field : table) {
                    System.out.println(
                        field.getName()
                        + " = "
                        + field.getString()
                    );
                }
            }

        } catch (Exception e) {
            System.out.println(
                "Unable to read table "
                + tableName
                + "."
            );
            System.out.println(
                "Reason: " + e.getMessage()
            );
        }
    }

    private static Properties loadProperties()
        throws Exception {

        Properties properties = new Properties();

        FileInputStream input = null;

        try {
            input = new FileInputStream(CONFIG_FILE);
            properties.load(input);

        } finally {
            if (input != null) {
                input.close();
            }
        }

        validateProperty(
            properties,
            DestinationDataProvider.JCO_ASHOST
        );

        validateProperty(
            properties,
            DestinationDataProvider.JCO_SYSNR
        );

        validateProperty(
            properties,
            DestinationDataProvider.JCO_CLIENT
        );

        validateProperty(
            properties,
            DestinationDataProvider.JCO_USER
        );

        validateProperty(
            properties,
            DestinationDataProvider.JCO_PASSWD
        );

        return properties;
    }

    private static void validateProperty(
        Properties properties,
        String propertyName
    ) {
        String value =
            properties.getProperty(propertyName);

        if (
            value == null
            || value.trim().length() == 0
        ) {
            throw new RuntimeException(
                "Missing SAP configuration property: "
                + propertyName
            );
        }
    }

    private static void registerDestinationProvider(
        Properties properties
    ) {
        if (
            Environment
                .isDestinationDataProviderRegistered()
        ) {
            return;
        }

        Environment.registerDestinationDataProvider(
            new LocalDestinationProvider(properties)
        );
    }

    private static class LocalDestinationProvider
        implements DestinationDataProvider {

        private final Properties properties;

        LocalDestinationProvider(
            Properties properties
        ) {
            this.properties = properties;
        }

        @Override
        public Properties getDestinationProperties(
            String destinationName
        ) {
            if (
                DESTINATION_NAME.equals(destinationName)
            ) {
                return properties;
            }

            return null;
        }

        @Override
        public boolean supportsEvents() {
            return false;
        }

        @Override
        public void setDestinationDataEventListener(
            DestinationDataEventListener listener
        ) {
            // Static configuration does not require events.
        }
    }
}